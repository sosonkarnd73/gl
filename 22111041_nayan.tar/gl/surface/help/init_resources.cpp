int init_resources(char** model_filename, char* vshader_filename, char* fshader_filename)
{
     mesh_object->load_obj(model_filename, NULL);
     mesh_object->upload();

     /* Compile and link shaders */
     GLint link_ok = GL_FALSE;
     GLint validate_ok = GL_FALSE;

     GLuint vs, fs;
     if ((vs = create_shader(vshader_filename, GL_VERTEX_SHADER))   == 0) return 0;
     if ((fs = create_shader(fshader_filename, GL_FRAGMENT_SHADER)) == 0) return 0;

     program = glCreateProgram();

     glAttachShader(program, vs);
     glAttachShader(program, fs);
     glLinkProgram(program);

     glGetProgramiv(program, GL_LINK_STATUS, &link_ok);
     if (!link_ok) {
	  fprintf(stderr, "glLinkProgram:");
	  print_log(program);
	  return 0;
     }
     
     glValidateProgram(program);
     glGetProgramiv(program, GL_VALIDATE_STATUS, &validate_ok);
     if (!validate_ok) {
	  fprintf(stderr, "glValidateProgram:");
	  print_log(program);
     }

     const char* attribute_name;
     attribute_name = "v_coord";
     attribute_v_coord = glGetAttribLocation(program, attribute_name);
     if (attribute_v_coord == -1) {
	  fprintf(stderr, "Could not bind attribute %s\n", attribute_name);
	  return 0;
     }
     attribute_name = "v_normal";
     attribute_v_normal = glGetAttribLocation(program, attribute_name);
     if (attribute_v_normal == -1) {
	  fprintf(stderr, "Could not bind attribute %s\n", attribute_name);
	  return 0;
     }
     const char* uniform_name;
     uniform_name = "m";
     uniform_m = glGetUniformLocation(program, uniform_name);
     if (uniform_m == -1) {
	  fprintf(stderr, "Could not bind uniform %s\n", uniform_name);
	  return 0;
     }
     uniform_name = "v";
     uniform_v = glGetUniformLocation(program, uniform_name);
     if (uniform_v == -1) {
	  fprintf(stderr, "Could not bind uniform %s\n", uniform_name);
	  return 0;
     }
     uniform_name = "p";
     uniform_p = glGetUniformLocation(program, uniform_name);
     if (uniform_p == -1) {
	  fprintf(stderr, "Could not bind uniform %s\n", uniform_name);
	  return 0;
     }
     uniform_name = "m_3x3_inv_transp";
     uniform_m_3x3_inv_transp = glGetUniformLocation(program, uniform_name);
     if (uniform_m_3x3_inv_transp == -1) {
	  fprintf(stderr, "Could not bind uniform %s\n", uniform_name);
	  return 0;
     }
     uniform_name = "v_inv";
     uniform_v_inv = glGetUniformLocation(program, uniform_name);
     if (uniform_v_inv == -1) {
	  fprintf(stderr, "Could not bind uniform %s\n", uniform_name);
	  return 0;
     }
     
     return 1;
}
